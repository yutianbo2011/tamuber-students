Given(/I try to visit the \/transit page/) do
    visit('/transit')
end

Given(/I try to visit the \/pickup page/) do 
    visit('/pickup')
end

Given(/I try to visit the \/end page/) do 
    visit('/end')
end